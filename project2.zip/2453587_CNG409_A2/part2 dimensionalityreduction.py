import pickle
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from umap import UMAP  

# Load datasets
dataset1 = pickle.load(open("../data/part2_dataset_1.data", "rb"))
dataset2 = pickle.load(open("../data/part2_dataset_2.data", "rb"))

# Function to visualize 2D scatter plot
def plot_scatter(data, title):
    """Plot a scatter plot for 2D data."""
    plt.scatter(data[:, 0], data[:, 1])  # Plot the first two components
    plt.title(title)# Set the title of the plot
    plt.xlabel('x label')
    plt.ylabel('y label')
    plt.show() # Display the plot

# PCA
pca = PCA(n_components=2)
dataset1_pca = pca.fit_transform(dataset1)
dataset2_pca = pca.fit_transform(dataset2)
plot_scatter(dataset1_pca, 'Dataset 1 - PCA')
plot_scatter(dataset2_pca, 'Dataset 2 - PCA')

# t-SNE
tsne = TSNE(n_components=2, perplexity=30, n_iter=300)  
dataset1_tsne = tsne.fit_transform(dataset1)
dataset2_tsne = tsne.fit_transform(dataset2)
plot_scatter(dataset1_tsne, 'Dataset 1 - t-SNE')
plot_scatter(dataset2_tsne, 'Dataset 2 - t-SNE')

# UMAP
umap = UMAP(n_components=2, n_neighbors=15, min_dist=0.1)  
dataset1_umap = umap.fit_transform(dataset1)
dataset2_umap = umap.fit_transform(dataset2)
plot_scatter(dataset1_umap, 'Dataset 1 - UMAP')
plot_scatter(dataset2_umap, 'Dataset 2 - UMAP')
