import numpy as np
import pickle
from Distance import Distance
class KNN:
    def __init__(self, dataset, data_label, similarity_function, similarity_function_parameters=None, K=1):
        """
        :param dataset: dataset on which KNN is executed, 2D numpy array
        :param data_label: class labels for each data sample, 1D numpy array
        :param similarity_function: similarity/distance function, Python function
        :param similarity_function_parameters: auxiliary parameter or parameter array for distance metrics
        :param K: how many neighbors to consider, integer
        """
        self.K = K
        self.dataset = dataset
        self.dataset_label = data_label
        self.similarity_function = similarity_function
        self.similarity_function_parameters = similarity_function_parameters

    def predict(self, instance):
         # Calculate distances between the instance and all points in the dataset
        distances = [self.similarity_function(instance, data_point, *self.similarity_function_parameters)
                     for data_point in self.dataset]

        # Get indices of the K nearest neighbors
        k_nearest_indices = np.argsort(distances)[:self.K]

        # Extract the labels of the K nearest neighbors
        k_nearest_labels = [self.data_label[i] for i in k_nearest_indices]

        # Return the most common label among the K nearest neighbors
        return max(set(k_nearest_labels), key=k_nearest_labels.count)
    



