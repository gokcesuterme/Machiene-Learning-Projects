from Distance import Distance
import numpy as np
class KMeans:
    def __init__(self, dataset, K=2):
        """
        :param dataset: 2D numpy array, the whole dataset to be clustered
        :param K: integer, the number of clusters to form
        """
        self.K = K
        self.dataset = dataset
        # each cluster is represented with an integer index
        # self.clusters stores the data points of each cluster in a dictionary
        self.clusters = {i: [] for i in range(K)}
        # self.cluster_centers stores the cluster mean vectors for each cluster in a dictionary
        self.cluster_centers = {i: None for i in range(K)}
        # you are free to add further variables and functions to the class

    def calculateLoss(self):
        """Loss function implementation of Equation 1"""
        loss = 0
        for idx, center in enumerate(self.cluster_centers):
            cluster_points = self.dataset[self.labels == idx]
            loss += np.sum((cluster_points - center) ** 2)
        return loss

    def run(self):
        max_iter=100
        for _ in range(max_iter):
            """Kmeans algorithm implementation"""
            # Assign points to the nearest cluster center
            self.labels = np.array([np.argmin(np.linalg.norm(self.dataset - center, axis=1)) for center in self.cluster_centers])

            # Update cluster centers
            new_centers = np.array([self.dataset[self.labels == i].mean(axis=0) for i in range(self.K)])
            
            # Check for convergence (if centers do not change)
            if np.all(new_centers == self.cluster_centers):
                break

            self.cluster_centers = new_centers

        return self.cluster_centers, self.labels, self.calculateLoss()
