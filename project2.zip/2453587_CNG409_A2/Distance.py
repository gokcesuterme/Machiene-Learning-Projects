import numpy as np
import math
class Distance:
    @staticmethod
        
        #Calculate the cosine distance between two vectors x and y.
        #calculated as the dot product of x and y divided by the product of their norms.
    def calculateCosineDistance(x, y):
        return 1 - np.dot(x, y) / (np.linalg.norm(x) * np.linalg.norm(y))
        
    @staticmethod
        #Calculate the Minkowski distance between two vectors x and y.
        #This is a generalization of other distances: for p=2, it's Euclidean distance; for p=1, it's Manhattan distance.
        #It's calculated as the p-th root of the sum of the absolute differences raised to the power p.
    def calculateMinkowskiDistance(x, y, p=2):
        return np.sum(np.abs(x - y) ** p) ** (1 / p) 
        
    @staticmethod
        #Calculate the Mahalanobis distance between two vectors x and y.
        #This distance measures the distance between a point and a distribution.
        #It's calculated using the inverse of the covariance matrix (S_minus_1) of the data.
    def calculateMahalanobisDistance(x,y, S_minus_1):
        difference = x - y
        return np.sqrt(np.dot(np.dot(difference.T, S_minus_1), difference))



