from Kmeans import KMeans
import pickle
import numpy as np
import matplotlib.pyplot as plt

dataset1 = pickle.load(open("../data/part2_dataset_1.data", "rb"))
dataset2 = pickle.load(open("../data/part2_dataset_2.data", "rb"))
def run_kmeans(dataset, k_range, iterations, repeats):
    avg_loss_values = []
    for k in k_range:
        repeat_loss_values = []
        for _ in range(repeats):
            loss_values = []
            for _ in range(iterations):
                kmeans = KMeans(dataset, K=k)
                _, _, loss = kmeans.run()
                loss_values.append(loss)
            repeat_loss_values.append(min(loss_values))
        avg_loss_values.append(np.mean(repeat_loss_values))
    return avg_loss_values
k_range = range(2, 11)
iterations = 10
repeats = 10

avg_loss_dataset1 = run_kmeans(dataset1, k_range, iterations, repeats)
avg_loss_dataset2 = run_kmeans(dataset2, k_range, iterations, repeats)

#ploting the grapgh    
k_range = range(2, 11)
plt.figure(figsize=(10, 5))
# Plot for dataset 1
plt.subplot(1, 2, 1)
plt.plot(k_range, avg_loss_dataset1, marker='o')
plt.title("KMeans - Dataset 1")
plt.xlabel("Number of Clusters (K)")
plt.ylabel("Average Loss")
plt.grid(True)

# Plot for dataset 2
plt.subplot(1, 2, 2)
plt.plot(k_range, avg_loss_dataset2, marker='o')
plt.title("KMeans - Dataset 2")
plt.xlabel("Number of Clusters (K)")
plt.ylabel("Average Loss")
plt.grid(True)
plt.tight_layout()
plt.show()
