import pickle
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from umap import UMAP

# Load dataset
dataset = pickle.load(open("../data/part3_dataset.data", "rb"))

# Function to plot scatter plots
def plot_scatter(data, title):
    """Plot a 2D scatter plot for the given data."""
    plt.scatter(data[:, 0], data[:, 1])
    plt.title(title)
    plt.xlabel('Component 1')
    plt.ylabel('Component 2')
    plt.show()

# Apply PCA for dimensionality reduction and visualize
# PCA
pca = PCA(n_components=2) # Reducing to 2 components for 2D visualization
data_pca = pca.fit_transform(dataset)
plot_scatter(data_pca, "PCA 2D Visualization")

# Apply t-SNE for dimensionality reduction and visualize
# t-SNE
tsne = TSNE(n_components=2, perplexity=30, n_iter=300) 
data_tsne = tsne.fit_transform(dataset)
plot_scatter(data_tsne, "t-SNE 2D Visualization")

# UMAP
# Apply UMAP for dimensionality reduction and visualize
umap = UMAP(n_components=2, n_neighbors=15, min_dist=0.1) 
data_umap = umap.fit_transform(dataset)
plot_scatter(data_umap, "UMAP 2D Visualization")
