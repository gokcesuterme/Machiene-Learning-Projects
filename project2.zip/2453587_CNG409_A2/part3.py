import pickle
import numpy as np
from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics import silhouette_score

# Load dataset
dataset = pickle.load(open("../data/part3_dataset.data", "rb"))

# Hyperparameters
linkage_criteria = ['single', 'complete'] # Types of linkage to test
distance_measures = ['euclidean', 'cosine'] # Types of distance measures to test
k_values = [2, 3, 4, 5] # Values of K (number of clusters) to test

best_score = -1 # Initialize the best silhouette score
best_config = None # Initialize the best configuration

# Experimentation with different hyperparameter configurations
for linkage in linkage_criteria:
    for distance in distance_measures:
        for k in k_values:
             # Apply Agglomerative Clustering with current configuration
            clustering = AgglomerativeClustering(n_clusters=k, affinity=distance, linkage=linkage)
            labels = clustering.fit_predict(dataset)

             # Compute the average silhouette score
            silhouette_avg = silhouette_score(dataset, labels)
            print(f"Linkage: {linkage}, Distance: {distance}, K: {k}, Silhouette Score: {silhouette_avg}")

            # Update the best configuration if current is better
            if silhouette_avg > best_score:
                best_score = silhouette_avg
                best_config = (linkage, distance, k)

# Print the best configuration and its silhouette score
print(f"Best Configuration: {best_config}, with Silhouette Score: {best_score}")
