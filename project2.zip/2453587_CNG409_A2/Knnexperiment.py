import pickle
import numpy as np
from sklearn.model_selection import StratifiedKFold
from Distance import Distance
from Knn import KNN
dataset, labels = pickle.load(open("../data/part1_dataset.data", "rb"))
# Function to calculate the confidence interval
def confidence_interval(data):
    mean = np.mean(data)
    std = np.std(data, ddof=1)  # Sample standard deviation
    z_score = 1.96  # Approximate Z-score for confidence
    margin_of_error = z_score * (std / np.sqrt(len(data)))

    lower_bound = mean - margin_of_error
    upper_bound = mean + margin_of_error
    return lower_bound, upper_bound


# Define hyperparameter configurations
n_splits = 10
n_repeats = 5
hyperparameter_configurations = [
    (3, Distance.calculateCosineDistance), 
    (5, Distance.calculateCosineDistance),
    (3, Distance.calculateMinkowskiDistance), 
    (5, Distance.calculateMinkowskiDistance),
    (3, Distance.calculateMahalanobisDistance)
]

# Function for KNN cross-validation
def perform_knn_cv(dataset, labels, K, distance_function):
    accuracies = []
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=None)

    for train_index, test_index in skf.split(dataset, labels):
        X_train, X_test = dataset[train_index], dataset[test_index]
        y_train, y_test = labels[train_index], labels[test_index]

        # Initialize KNN
        knn = KNN(X_train, y_train, distance_function, K=K)
        
        # Predict and calculate accuracy
        correct_predictions = sum(knn.predict(X_test[i]) == y_test[i] for i in range(len(y_test)))
        accuracy = correct_predictions / len(y_test)
        accuracies.append(accuracy)
    
    return accuracies

# Experimentation and computing confidence intervals
results = {}
for K, distance_function in hyperparameter_configurations:
    all_accuracies = []

    for _ in range(n_repeats):
        # Shuffle the dataset
        indices = np.arange(len(labels))
        np.random.shuffle(indices)
        shuffled_dataset = dataset[indices]
        shuffled_labels = labels[indices]

        # Perform cross-validation
        accuracies = perform_knn_cv(shuffled_dataset, shuffled_labels, K, distance_function)
        all_accuracies.extend(accuracies)

    # Compute mean accuracy and confidence interval
    mean_accuracy = np.mean(all_accuracies)
    ci_lower, ci_upper = confidence_interval(all_accuracies)
    results[(K, distance_function.__name__)] = (mean_accuracy, (ci_lower, ci_upper))

# Displaying results
for key, value in results.items():
    print(f"K={key[0]}, Distance={key[1]}, Mean Accuracy={value[0]:.2f}, CI=({value[1][0]:.2f}, {value[1][1]:.2f})")
