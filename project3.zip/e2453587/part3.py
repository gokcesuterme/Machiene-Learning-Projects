import numpy as np
from DataLoader import DataLoader
from sklearn.model_selection import RepeatedStratifiedKFold, GridSearchCV
from sklearn.preprocessing import MinMaxScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, f1_score

# Load dataset
data_path = "data/credit.data"
dataset, labels = DataLoader.load_credit_with_onehot(data_path)

# Algorithms and hyperparameters
algorithms = {
    'KNN': KNeighborsClassifier(),
    'SVM': SVC(),
    'Decision Tree': DecisionTreeClassifier(),
    'Random Forest': RandomForestClassifier()
}

param_grids = {
    'KNN': {'classifier__n_neighbors': [3, 5, 7]},  # Prepend 'classifier__' to parameter names
    'SVM': {'classifier__C': [0.1, 1, 10], 'classifier__kernel': ['linear', 'rbf']},
    'Decision Tree': {'classifier__max_depth': [3, 5, 10], 'classifier__min_samples_split': [2, 4]},
    'Random Forest': {'classifier__n_estimators': [10, 50, 100], 'classifier__max_depth': [3, 5, None]}
}

# Cross-Validation Setup
outer_cv = RepeatedStratifiedKFold(n_splits=5, n_repeats=3)
inner_cv = RepeatedStratifiedKFold(n_splits=10, n_repeats=3)

# Store results
results = {}
best_hyperparameters = {}

# Algorithm comparison loop
for name, algorithm in algorithms.items():
    pipeline = Pipeline([
        ('scaler', MinMaxScaler()),
        ('classifier', algorithm)
    ])

    grid_search = GridSearchCV(pipeline, param_grids[name], cv=inner_cv)
    scores = []

    # Nested cross-validation
    for train_idx, test_idx in outer_cv.split(dataset, labels):
        X_train, X_test = dataset[train_idx], dataset[test_idx]
        y_train, y_test = labels[train_idx], labels[test_idx]

        grid_search.fit(X_train, y_train)
        best_model = grid_search.best_estimator_
        predictions = best_model.predict(X_test)
        scores.append((accuracy_score(y_test, predictions), f1_score(y_test, predictions)))

    results[name] = scores
    best_hyperparameters[name] = grid_search.best_params_

# Print results
for name, scores in results.items():
    acc_scores, f1_scores = zip(*scores)
    print(f"{name}: Accuracy: {np.mean(acc_scores):.2f}±{np.std(acc_scores):.2f}, F1: {np.mean(f1_scores):.2f}±{np.std(f1_scores):.2f}")
    print(f"Best Hyperparameters for {name}: {best_hyperparameters[name]}")