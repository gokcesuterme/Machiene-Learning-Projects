import pickle
import numpy as np
from sklearn.model_selection import GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.svm import SVC

# Load dataset
dataset, labels = pickle.load(open("../data/part2_dataset2.data", "rb"))

# Define the parameter grid
param_grid = {
    'svc__C': [1, 10],  # Example values, adjust as needed
    'svc__kernel': ['linear', 'rbf']
    # Add more parameters here if needed
}

# Create a pipeline with StandardScaler and SVC
pipeline = Pipeline([
    ('scaler', StandardScaler()),
    ('svc', SVC())
])

# Setup GridSearchCV
grid_search = GridSearchCV(pipeline, param_grid, cv=10, scoring='accuracy')  # Adjust scoring as needed

# Fit the model
grid_search.fit(dataset, labels)

# Results analysis
results = grid_search.cv_results_
for param, score in zip(results["params"], results["mean_test_score"]):
    print(param, 'has a mean test score of', score)
