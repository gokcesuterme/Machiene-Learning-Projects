import numpy as np
# In the decision tree, non-leaf nodes are going to be represented via TreeNode
class TreeNode:
    def __init__(self, attribute):
        self.attribute = attribute
        # dictionary, k: subtree, key (k) an attribute value, value is either TreeNode or TreeLeafNode
        self.subtrees = {}

# In the decision tree, leaf nodes are going to be represented via TreeLeafNode
class TreeLeafNode:
    def __init__(self, data, label):
        self.data = data
        self.labels = label

class DecisionTree:
    def __init__(self, dataset: list, labels, features, criterion="information gain"):
        """
        :param dataset: array of data instances, each data instance is represented via an Python array
        :param labels: array of the labels of the data instances
        :param features: the array that stores the name of each feature dimension
        :param criterion: depending on which criterion ("information gain" or "gain ratio") the splits are to be performed
        """
        self.dataset = dataset
        self.labels = labels
        self.features = features
        self.criterion = criterion
        # it keeps the root node of the decision tree
        self.root = None

        # further variables and functions can be added...


    def calculate_entropy__(self, dataset, labels):
        """
        :param dataset: array of the data instances
        :param labels: array of the labels of the data instances
        :return: calculated entropy value for the given dataset
        """
        entropy_value = 0.0

        """
        Entropy calculations
        """
        label_counts = {}  # Stores the count of each label in the dataset

        # Count the labels
        for label in labels:
            if label in label_counts:
                label_counts[label] += 1
            else:
                label_counts[label] = 1

        # Calculate entropy
        for label in label_counts:
            prob = label_counts[label] / len(labels)
            entropy_value -= prob * math.log2(prob)

        return entropy_value

    def calculate_average_entropy__(self, dataset, labels, attribute):
        """
        :param dataset: array of the data instances on which an average entropy value is calculated
        :param labels: array of the labels of those data instances
        :param attribute: for which attribute an average entropy value is going to be calculated...
        :return: the calculated average entropy value for the given attribute
        """
        average_entropy = 0.0
        attribute_values = set([data[self.features.index(attribute)] for data in dataset])
        total_size = len(dataset)

        for value in attribute_values:
            subset = [dataset[i] for i in range(len(dataset)) if dataset[i][self.features.index(attribute)] == value]
            subset_labels = [labels[i] for i in range(len(labels)) if dataset[i][self.features.index(attribute)] == value]
        
            subset_entropy = self.calculate_entropy__(subset, subset_labels)
            weight = len(subset) / total_size
            average_entropy += weight * subset_entropy
        return average_entropy

    def calculate_information_gain__(self, dataset, labels, attribute):
        """
        :param dataset: array of the data instances on which an information gain score is going to be calculated
        :param labels: array of the labels of those data instances
        :param attribute: for which attribute the information gain score is going to be calculated...
        :return: the calculated information gain score
        """
        information_gain = 0.0
        total_entropy = self.calculate_entropy__(dataset, labels)
        average_entropy = self.calculate_average_entropy__(dataset, labels, attribute)
        information_gain = total_entropy - average_entropy
        return information_gain

    def calculate_intrinsic_information__(self, dataset, labels, attribute):
        """
        :param dataset: array of data instances on which an intrinsic information score is going to be calculated
        :param labels: array of the labels of those data instances
        :param attribute: for which attribute the intrinsic information score is going to be calculated...
        :return: the calculated intrinsic information score
        """
        intrinsic_info = 0.0
        attribute_values = set([data[self.features.index(attribute)] for data in dataset])
        total_size = len(dataset)

        for value in attribute_values:
            subset_size = sum([1 for data in dataset if data[self.features.index(attribute)] == value])
            proportion = subset_size / total_size
            intrinsic_info -= proportion * math.log2(proportion) if proportion > 0 else 0

        return intrinsic_info
    def calculate_gain_ratio__(self, dataset, labels, attribute):
        """
        :param dataset: array of data instances with which a gain ratio is going to be calculated
        :param labels: array of labels of those instances
        :param attribute: for which attribute the gain ratio score is going to be calculated...
        :return: the calculated gain ratio score
        """
        information_gain = self.calculate_information_gain__(dataset, labels, attribute)
        intrinsic_info = self.calculate_intrinsic_information__(dataset, labels, attribute)

        # Avoid division by zero; if intrinsic_info is 0, gain ratio is undefined
        gain_ratio = information_gain / intrinsic_info if intrinsic_info != 0 else 0

        return gain_ratio

    def ID3__(self, dataset, labels, used_attributes):
        """
        Recursive function for ID3 algorithm
        :param dataset: data instances falling under the current  tree node
        :param labels: labels of those instances
        :param used_attributes: while recursively constructing the tree, already used labels should be stored in used_attributes
        :return: it returns a created non-leaf node or a created leaf node
        """
        # Base case: If all labels are the same, return a leaf node
        if all(label == labels[0] for label in labels):
            return TreeLeafNode(dataset, labels[0])
        
        # Base case: If no more attributes to use, return a leaf node with the most common label
        if len(used_attributes) == len(self.features):
            return TreeLeafNode(dataset, max(set(labels), key=labels.count))
        
        # Choose the best attribute to split
        best_attribute = None
        best_score = float('-inf')

        for attribute in self.features:
            if attribute not in used_attributes:
                if self.criterion == "information gain":
                    score = self.calculate_information_gain__(dataset, labels, attribute)
                else:
                    score = self.calculate_gain_ratio__(dataset, labels, attribute)
                
                if score > best_score:
                    best_attribute = attribute
                    best_score = score

        # Create a node for the best attribute
        node = TreeNode(best_attribute)
        used_attributes.add(best_attribute)

        # Partition the dataset and recursively apply ID3 on each partition
        attribute_index = self.features.index(best_attribute)
        attribute_values = set(data[attribute_index] for data in dataset)

        for value in attribute_values:
            subset = [data for data in dataset if data[attribute_index] == value]
            subset_labels = [labels[i] for i in range(len(labels)) if dataset[i][attribute_index] == value]
            
            # Recursive call
            subtree = self.ID3__(subset, subset_labels, used_attributes.copy())
            node.subtrees[value] = subtree

        return node


    def predict(self, x):
        """
        :param x: a data instance, 1 dimensional Python array 
        :return: predicted label of x
        
        If a leaf node contains multiple labels in it, the majority label should be returned as the predicted label
        """
        predicted_label = None
        # Start from the root of the tree
        node = self.root

        while not isinstance(node, TreeLeafNode):
            # Traverse the tree based on the attribute value in x
            attribute_value = x[self.features.index(node.attribute)]
            if attribute_value in node.subtrees:
                node = node.subtrees[attribute_value]
            else:
                # Handle the case where the attribute value is not in the tree
                predicted_label = max(set(self.labels), key=self.labels.count)
                return predicted_label

        # If a leaf node contains multiple labels, return the majority label
        if isinstance(node.labels, list):
            predicted_label = max(set(node.labels), key=node.labels.count)
        else:
            predicted_label = node.labels

        return predicted_label

    def train(self):
        self.root = self.ID3__(self.dataset, self.labels, [])
        print("Training completed")